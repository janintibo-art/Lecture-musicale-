# Le son du Tibo — APK Android

Wrapper Android natif pour le lecteur multimédia **Le son du Tibo** (lecteur HTML5 tout-en-un : radios internet, EQ 31 bandes, filtres Hi-Fi, mastering, réveils, etc).

## 📦 Construire l'APK automatiquement sur GitHub

1. **Créer un repo GitHub** (public ou privé, peu importe).
2. **Décompresser** ce ZIP à la racine du repo (le dossier `.github/workflows/` doit être à la racine, pas dans un sous-dossier).
3. **Push** vers `main` (ou `master`).
4. GitHub Actions se déclenche automatiquement. Suivi dans l'onglet **Actions**.
5. Une fois terminé (≈ 4-6 min), téléchargez l'APK dans **Actions → dernier run → Artifacts → LeSonDuTibo-debug**.

Pour publier une **Release officielle** : créez un tag `v1.0.0` et pushez-le. Le workflow joint automatiquement les APK à une release GitHub.

```bash
git tag v1.0.0
git push origin v1.0.0
```

## 🛠️ Construire en local (optionnel)

Pré-requis : **Android Studio Hedgehog ou +** ou bien **JDK 17** + **Android SDK 34** + **Gradle 8.5**.

```bash
gradle wrapper --gradle-version 8.5
./gradlew assembleDebug
# APK généré dans app/build/outputs/apk/debug/
```

## 📁 Structure

```
.
├── .github/workflows/build-apk.yml   ← Workflow GitHub Actions
├── app/
│   ├── build.gradle                   ← Config module Android
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml        ← Permissions (audio, micro, réseau)
│       ├── assets/index.html          ← L'app Tibo (HTML autonome)
│       ├── java/fr/tibo/son/
│       │   └── MainActivity.java      ← WebView host
│       └── res/
│           ├── drawable/              ← Icône vectorielle
│           ├── layout/                ← Layout WebView plein écran
│           ├── mipmap-anydpi-v26/     ← Adaptive icon
│           ├── values/                ← Strings, couleurs, thème
│           └── xml/                   ← Network security config (HTTP autorisé)
├── build.gradle                       ← Config racine
├── gradle.properties
└── settings.gradle
```

## 🔐 Signer l'APK release (optionnel)

L'APK **debug** est auto-signé et installable. Pour une release distribuable :

1. Générer un keystore : `keytool -genkey -v -keystore tibo.keystore -alias tibo -keyalg RSA -keysize 2048 -validity 10000`
2. Encoder en base64 : `base64 tibo.keystore > tibo.keystore.b64`
3. Dans le repo GitHub : **Settings → Secrets → Actions**, ajouter :
   - `KEYSTORE_B64` (contenu du fichier .b64)
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS` (= `tibo`)
   - `KEY_PASSWORD`
4. Modifier `app/build.gradle` pour ajouter le bloc `signingConfigs` (voir doc Android officielle).

## 📋 Personnaliser

- **Nom de l'app** : `app/src/main/res/values/strings.xml` → `app_name`
- **Couleurs** : `app/src/main/res/values/colors.xml`
- **Icône** : remplacer `app/src/main/res/drawable/ic_launcher_foreground.xml` par votre vecteur (ou ajouter des PNG dans `mipmap-mdpi/`, `mipmap-hdpi/`, etc.)
- **Package name** : `app/build.gradle` → `namespace` et `applicationId` (penser à renommer le dossier `app/src/main/java/fr/tibo/son/`)
- **Mettre à jour l'app** : remplacer `app/src/main/assets/index.html` puis pousser sur GitHub

## ⚙️ Caractéristiques techniques

- **min SDK** 23 (Android 6.0, couvre 98 % des appareils actifs)
- **target SDK** 34 (Android 14)
- **Architecture** : universel (le WebView est compilé pour toutes les architectures)
- **Permissions runtime** : RECORD_AUDIO, READ_MEDIA_AUDIO, POST_NOTIFICATIONS demandées au 1ᵉʳ lancement
- **HTTP cleartext autorisé** : nécessaire pour beaucoup de flux radio associatifs
- **Audio en arrière-plan** : la WebView n'est pas mise en pause sur `onPause`, l'audio continue écran éteint
- **Bouton retour** : ferme les modales/mode nuit/notif réveil avant de mettre l'app en arrière-plan

## 🚀 Limites connues

- Les **flux HTTP** marchent grâce à `usesCleartextTraffic`, mais les routeurs/réseaux d'entreprise peuvent les bloquer.
- **Programmation d'enregistrement** et **réveils** nécessitent que l'app reste ouverte (pas de service système).
- Le **stockage des playlists** est local (localStorage) : une désinstallation efface tout. Pensez à exporter en M3U si vous voulez sauvegarder.

---

Bonne écoute 🎵
